#include <stdio.h>
#include "flash_utils.h"

int main()
{
    char addr[80];

    sprintf(addr, "address = %x", getAddressPersistent());
    return 0;
}
